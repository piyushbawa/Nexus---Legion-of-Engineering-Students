import pandas as pd
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','capstone.settings')

import django
django.setup()

from website.models import courses
df = pd.read_excel("C:\PIYUSH\CAPSTONE\PROJECT\capstone\ALL SUB.xlsx", sheet_name="Sheet1")
# print(df)
c=1
for index,row in df.iterrows():
    myuser=courses(c,row['Course Name'],row['Links'],row['Books'])
    c=c+1
    myuser.save()
