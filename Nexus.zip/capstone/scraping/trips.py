import pandas as pd
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','capstone.settings')

import django
django.setup()

from website.models import tripimg
df = pd.read_excel("C:\PIYUSH\CAPSTONE\PROJECT\capstone\TRIPS.xlsx", sheet_name="Sheet1")
c=1
for index,row in df.iterrows():
    myuser1=tripimg(c,row['name'],row['link'])
    c=c+1
    myuser1.save()
