from django.contrib import admin
from . import models
# Register your models here.
admin.site.register(models.student)
admin.site.register(models.professor)
admin.site.register(models.project)
admin.site.register(models.event)
admin.site.register(models.society)
admin.site.register(models.courses)
admin.site.register(models.trips)
admin.site.register(models.tripimg)
admin.site.register(models.discussion)
admin.site.register(models.movies)
admin.site.register(models.rating)
admin.site.register(models.count)