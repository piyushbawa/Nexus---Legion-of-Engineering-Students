from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('signup/',views.signup,name='signup'),
    path('signin/',views.signin,name='signin'),
    path('otp/',views.otp,name='otp'),
    path('signup_stu/',views.signup_stu,name='signup_stu'),
    path('landing/',views.landing,name='landing'),
    path('course/<int:id>/',views.course,name='course'),
    path('course/search/',views.search,name='search'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('signout/',views.signout,name="signout"),
    path('trips/',views.trips,name='trips'),
    path('tripi/',views.tripi,name='tripi'),
    path('project/',views.project,name='project'),
    path('movies/',views.movies,name='movies'),
    path('recommend/',views.recommend,name='recommend'),
    # path('games/',views.games,name='games'),
    path('society/',views.society,name='society'),
    path('eventform/',views.eventform,name='eventform'),
    path('projectform/',views.projectform,name='projectform'),
    # path('createtrip/',views.createtrip,name='createtrip')
]
