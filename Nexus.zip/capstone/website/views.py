from django import forms
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login
from django.core.mail import send_mail

from . import models
import re

def home(request):
    return redirect('landing')
def landing(request):
    request.session.set_expiry(1)
    myuser1=models.project.objects.all()
    projects=[]
    for i in myuser1:
        projects.append(i)
    myuser=models.event.objects.all()
    events=[]
    for i in myuser:
        events.append(i)
    myuser2=models.trips.objects.all()
    places=[]
    for i in myuser2:
        places.append(i)
    return render(request,'signup/landing.html',{"events":events,"projects":projects,"places":places})
def check_email(email):
    regex = re.compile('[_]')
    if regex.search(email) != None and any(chr.isdigit() for chr in email):
        return "Student"
    else:
        return "Faculty"

def signup_stu(request):
    if request.method=="POST":
        global branch
        global interest
        email=request.session['email']
        branch=request.POST['branch']
        interest=request.POST['interest']
        return redirect('otp')
    return render(request,'signup/signup_stu.html')

def signup(request):
    global email
    global fullname
    global passwd
    global cpasswd
    if request.method=="POST":
        fullname=request.POST['fullname']
        email=request.POST['email']
        if check_email(email)=="Student":
            passwd=request.POST['passwd']
            cpasswd=request.POST['cpasswd']
            if passwd==cpasswd:
                reg = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{6,20}$"
                pat = re.compile(reg)                
                mat = re.search(pat, passwd)
                if mat:
                    request.session['email']=email
                    return render(request,'signup/signup_stu.html')
                else:
                    messages.error(request,'Password should have atleast one number,one uppercase and one lowercase character,one special symbol. It should be 6-20 long')
            else:
                messages.error(request,'Passwords do not match')
        else:
            passwd=request.POST['passwd']
            cpasswd=request.POST['cpasswd']
            societylist = ['score@thapar.edu',
        'cogito@thapar.edu',
         'ccs@thapar.edu',
         'elpis@thapar.edu',
         'enactus@thapar.edu',
         'edc@thapar.ecu',
         'eureka@thapar.edu',
         'faps@thapar.edu',
         'froshweek@thapar.edu',
         'gene@thapar.edu',
         'girlup@thapar.edu',
         'lead_sc@thapar.edu',
         'lugtu@thapar.edu',
         'litsoc@thapar.edu',
         'maps@thapar.edu',
         'robotics@thapar.edu',
         'mudra@thapar.edu',
         'pws@thapar.edu',
         'pratigyasoc@thapar.edu',
         'spicmacay@thapar.edu',
         'somie@thapar.edu'
         'ssa@thapar.edu',
         'taas.astronomers@thapar.edu',
         'mathematical_soc@thapar.edu',
         'tsce@thapar.edu',
         'tumun@thapar.edu',
         'adventureclub@thapar.edu',
         'nox@thapar.edu',
         'google.dsctiet@thapar.edu',
         'echoes@thapar.edu',
         'econclub@thapar.edu',
         'ebsb@thapar.edu',
         'gcc@thapar.edu',
         'tmc@thapar.edu',
         'tietfitnessclub@thapar.edu',
         'toastmasters_sc@thapar.edu',
         'ywc@thapar.edu',
         'acmcomputingchapter@thapar.edu',
         'aiche_sc@thapar.edu',
         'ashrae_sc@thapar.edu',
         'iete_sc@thapar.edu',
         'iet_sc@thapar.edu',
         'iei_sc@thapar.edu',
         'iiche@thapar.edu',
         'iste_sc@thapar.edu',
         'kalam_sc@thapar.edu',
         'microsoft_sc@thapar.edu',
         'owasp_sc@thapar.edu',
         'rotaractclub_sc@thapar.edu',
         'sae_sc@thapar.edu',
         'tedx@thapar.edu',
         'yu@thapar.edu'
         ]
            if passwd==cpasswd:
                reg = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{6,20}$"
                pat = re.compile(reg)                
                mat = re.search(pat, passwd)
                if mat:
                    return redirect('otp')
                else:
                    messages.error(request,'Password should have atleast one number,one uppercase and one lowercase character,one special symbol. It should be 6-20 long')
            else:
                messages.error(request,'Passwords do not match')
        
    return render(request,"signup/signup_1.html")
def otp(request):
    global no
    if request.method=="POST":
        otpp=request.POST['otp']
        if int(otpp)==int(no):
            if check_email(email)=="Student":
                myuser=models.student(fullname=fullname,passwd=passwd,cpasswd=cpasswd,email=email,branch=branch,interest=interest)
            else:
                societylist = ['score@thapar.edu',
        'cogito@thapar.edu',
         'ccs@thapar.edu',
         'elpis@thapar.edu',
         'enactus@thapar.edu',
         'edc@thapar.ecu',
         'eureka@thapar.edu',
         'faps@thapar.edu',
         'froshweek@thapar.edu',
         'gene@thapar.edu',
         'girlup@thapar.edu',
         'lead_sc@thapar.edu',
         'lugtu@thapar.edu',
         'litsoc@thapar.edu',
         'maps@thapar.edu',
         'robotics@thapar.edu',
         'mudra@thapar.edu',
         'pws@thapar.edu',
         'pratigyasoc@thapar.edu',
         'spicmacay@thapar.edu',
         'somie@thapar.edu'
         'ssa@thapar.edu',
         'taas.astronomers@thapar.edu',
         'mathematical_soc@thapar.edu',
         'tsce@thapar.edu',
         'tumun@thapar.edu',
         'adventureclub@thapar.edu',
         'nox@thapar.edu',
         'google.dsctiet@thapar.edu',
         'echoes@thapar.edu',
         'econclub@thapar.edu',
         'ebsb@thapar.edu',
         'gcc@thapar.edu',
         'tmc@thapar.edu',
         'tietfitnessclub@thapar.edu',
         'toastmasters_sc@thapar.edu',
         'ywc@thapar.edu',
         'acmcomputingchapter@thapar.edu',
         'aiche_sc@thapar.edu',
         'ashrae_sc@thapar.edu',
         'iete_sc@thapar.edu',
         'iet_sc@thapar.edu',
         'iei_sc@thapar.edu',
         'iiche@thapar.edu',
         'iste_sc@thapar.edu',
         'kalam_sc@thapar.edu',
         'microsoft_sc@thapar.edu',
         'owasp_sc@thapar.edu',
         'rotaractclub_sc@thapar.edu',
         'sae_sc@thapar.edu',
         'tedx@thapar.edu',
         'yu@thapar.edu'
         ]
                if email in societylist:
                    myuser=models.society(fullname=fullname,passwd=passwd,cpasswd=cpasswd,email=email)
                else:
                    myuser=models.professor(fullname=fullname,passwd=passwd,cpasswd=cpasswd,email=email)
            myuser.save()
            send_mail('Welcome','Welcome to NEXUS family','nexusthapar@gmail.com',[email])
            return redirect('signin')
        else:
            messages.error(request,'Invalid OTP')
            return redirect('signup') 
    else:
        import random
        no=random.randrange(1000,9999)
        send_mail('Your OTP for verification','Your OTP is {}'.format(no),'nexusthapar@gmail.com',[email])
        return render(request,"signup/otp.html")
def signin(request):
    if request.method=="POST":
        email=request.POST['email']
        passwd=request.POST['passwd']
        if check_email(email)=="Student":
            try:
                models.student.objects.get(email=email,passwd=passwd)
            except:
                messages.error(request,'Invalid email or password')
                return redirect('signin')
            myuser=models.student.objects.get(email=email,passwd=passwd)
            interest=myuser.interest
            fullname=myuser.fullname
            request.session['email']=email
            request.session['passwd']=passwd
            request.session.set_expiry(0)
            subjects=models.courses.objects.all()
            study=[]
            for i in subjects:
                study.append(i)
            return render(request,'signup/dashboard.html',{'interest':interest,'subjects':study,'fullname':fullname})
        else:
            request.session['email']=email
            societylist = ['score@thapar.edu',
        'cogito@thapar.edu',
         'ccs@thapar.edu',
         'elpis@thapar.edu',
         'enactus@thapar.edu',
         'edc@thapar.ecu',
         'eureka@thapar.edu',
         'faps@thapar.edu',
         'froshweek@thapar.edu',
         'gene@thapar.edu',
         'girlup@thapar.edu',
         'lead_sc@thapar.edu',
         'lugtu@thapar.edu',
         'litsoc@thapar.edu',
         'maps@thapar.edu',
         'robotics@thapar.edu',
         'mudra@thapar.edu',
         'pws@thapar.edu',
         'pratigyasoc@thapar.edu',
         'spicmacay@thapar.edu',
         'somie@thapar.edu'
         'ssa@thapar.edu',
         'taas.astronomers@thapar.edu',
         'mathematical_soc@thapar.edu',
         'tsce@thapar.edu',
         'tumun@thapar.edu',
         'adventureclub@thapar.edu',
         'nox@thapar.edu',
         'google.dsctiet@thapar.edu',
         'echoes@thapar.edu',
         'econclub@thapar.edu',
         'ebsb@thapar.edu',
         'gcc@thapar.edu',
         'tmc@thapar.edu',
         'tietfitnessclub@thapar.edu',
         'toastmasters_sc@thapar.edu',
         'ywc@thapar.edu',
         'acmcomputingchapter@thapar.edu',
         'aiche_sc@thapar.edu',
         'ashrae_sc@thapar.edu',
         'iete_sc@thapar.edu',
         'iet_sc@thapar.edu',
         'iei_sc@thapar.edu',
         'iiche@thapar.edu',
         'iste_sc@thapar.edu',
         'kalam_sc@thapar.edu',
         'microsoft_sc@thapar.edu',
         'owasp_sc@thapar.edu',
         'rotaractclub_sc@thapar.edu',
         'sae_sc@thapar.edu',
         'tedx@thapar.edu',
         'yu@thapar.edu'
         ]
            if email in societylist:
                try:
                    models.society.objects.get(email=email,passwd=passwd)
                except:
                    messages.error(request,'Invalid email or password')
                    return redirect('signin')
                myuser=models.society.objects.get(email=email,passwd=passwd)
                fullname=myuser.fullname
                return render(request,'signup/eventform.html',{'fullname':fullname})
            else:
                try:
                    models.professor.objects.get(email=email,passwd=passwd)
                except:
                    messages.error(request,'Invalid email or password')
                    return redirect('signin')
                myuser=models.professor.objects.get(email=email,passwd=passwd)
                fullname=myuser.fullname
                return render(request,'signup/projectform.html',{'fullname':fullname})
    return render(request,"signup/login.html")

def signout(request):
    request.session.set_expiry(1)
    return redirect('/landing')

def dashboard(request):
    email=request.session['email']
    passwd=request.session['passwd']
    myuser=models.student.objects.get(email=email,passwd=passwd)
    interest=myuser.interest
    fullname=myuser.fullname
    subjects=models.courses.objects.all()
    study=[]
    for i in subjects:
        study.append(i)
    return render(request,'signup/dashboard.html',{'interest':interest,'subjects':study,'fullname':fullname})

def search(request):
    if request.method=="POST":
        search=request.POST['search']
        email=request.session['email']
        passwd=request.session['passwd']
        myuser=models.student.objects.get(email=email,passwd=passwd)
        interest=myuser.interest
        fullname=myuser.fullname
        subjects=models.courses.objects.all()
        study=[]
        for i in subjects:
            if search.lower() in i.coursename.lower():
                study.append(i)
        return render(request,'signup/dashboard.html',{'interest':interest,'subjects':study,'fullname':fullname})

def course(request, id):
    if request.method=="POST":
        email=request.session['email']
        myuser=models.student.objects.get(email=email)
        fullname=myuser.fullname
        comment=request.POST['comment']
        myuser1=models.discussion(email=email,fullname=fullname,comment=comment,ids=id)
        myuser1.save()
    email=request.session['email']
    s=models.courses.objects.get(id=id)
    m1=models.discussion.objects.all()
    l1=[]
    for i in m1:
        if i.ids==id:
            l1.append(i)
    return render(request,"signup/course.html",{'s':s,'id':id,'l1':l1})

def eventform(request):
    if request.method=="POST":
        eventtitle=request.POST['eventtitle']
        description=request.POST['description']
        startdate=request.POST['startdate']
        enddate=request.POST['enddate']
        venue=request.POST['venue']
        instagramlink=request.POST['instagramlink']
        registrationlinks=request.POST['registrationlinks']
        email=request.session['email']
        imageurl=request.POST['imageurl']
        myuser1=models.society.objects.get(email=email)
        fullname=myuser1.fullname
        myuser=models.event(email=email)
        myuser.fullname=fullname
        myuser.eventtitle=eventtitle
        myuser.description=description
        myuser.startdate=startdate
        myuser.enddate=enddate
        myuser.venue=venue
        myuser.instagramlink=instagramlink
        myuser.registrationlinks=registrationlinks
        myuser.imageurl=imageurl
        modalid=re.sub(r'[^a-zA-Z]','',description)
        modalid=modalid.replace(" ","")
        myuser.modalfind=modalid
        myuser.save()
        return redirect('/landing')
    return render(request,'signup/eventform.html')

def projectform(request):
    if request.method=="POST":
        projecttitle=request.POST['projecttitle']
        description=request.POST['description']
        department=request.POST['department']
        startdate=request.POST['startdate']
        duration=request.POST['duration']
        applyby=request.POST['applyby']
        requiredskills=request.POST['requiredskills']
        perks=request.POST['perks']
        numberofstudents=request.POST['numberofstudents']
        email=request.session['email']
        myuser1=models.professor.objects.get(email=email)
        fullname=myuser1.fullname
        myuser=models.project(email=email)
        myuser.fullname=fullname
        myuser.projecttitle=projecttitle
        myuser.description=description
        myuser.department=department
        myuser.startdate=startdate
        myuser.duration=duration
        myuser.applyby=applyby
        myuser.requiredskills=requiredskills
        myuser.perks=perks
        myuser.numberofstudents=numberofstudents
        modalid=re.sub(r'[^a-zA-Z]','',description)
        modalid=modalid.replace(" ","")
        myuser.modalfind=modalid
        myuser.save()
        return redirect('/landing')
    return render(request,'signup/projectform.html')

def trips(request):
    if request.method=="POST":
        email=request.session['email']
        myuser1=models.student.objects.get(email=email)
        fullname=myuser1.fullname
        startdate=request.POST['startdate']
        enddate=request.POST['enddate']
        destination=request.POST['destination']
        perheadbudget=request.POST['perheadbudget']
        departure=request.POST['departure']
        myuser=models.trips(startdate=startdate,enddate=enddate,destination=destination,perheadbudget=perheadbudget,departure=departure,fullname=fullname,email=email)
        description=fullname+destination+email+departure
        modalid=re.sub(r'[^a-zA-Z]','',description)
        modalid=modalid.replace(" ","")
        myuser.modalfind=modalid
        link=models.tripimg.objects.get(name=destination)
        myuser.link=link.link
        myuser.save()
        return redirect('/trips')
    email=request.session['email']
    myuser=models.trips.objects.all()
    places=[]
    for i in myuser:
        places.append(i)
    return render(request,"signup/trips.html",{"places":places})

def tripi(request):
    if request.method=="POST":
        email=request.POST['email']
        e2=request.session['email']
        myuser=models.trips.objects.get(email=email)
        myuser.cnt=myuser.cnt+1
        myuser.save()
        send_mail('Interested','Hi I am interested to go on this trip. Please contact me on {}.'.format(e2),'nexusthapar@gmail.com',[email])
        return redirect('/trips')
    email=request.session['email']
    myuser=models.trips.objects.all()
    places=[]
    for i in myuser:
        places.append(i)
    return render(request,"signup/trips.html",{"places":places})

def project(request):
    email=request.session['email']
    myuser=models.project.objects.all()
    projects=[]
    for i in myuser:
        projects.append(i)
    return render(request,"signup/project.html",{'projects':projects})

def society(request):
    email=request.session['email']
    myuser=models.event.objects.all()
    events=[]
    for i in myuser:
        events.append(i)
    return render(request,"signup/society.html",{"events":events})
    
def movies(request):
    m1=models.movies.objects.all()
    if request.method=="POST":
        email=request.session['email']
        title=request.POST['title']
        try:
            models.rating.objects.get(email=email,title=title)
        except:
            myuser=models.rating(email=email,title=title)
            myuser.save()
        try:
            models.count.objects.get(title=title)
        except:
            myuser1=models.count(title=title,val=1)
            myuser1.save()
            return render(request,"signup/movies.html",{"m1":m1})
        myuser1=models.count.objects.get(title=title)
        myuser1.val=myuser1.val+1
        myuser1.save()        
    email=request.session['email']
    return render(request,"signup/movies.html",{"m1":m1})

def recommend(request):
    email=request.session['email']
    obj1=models.count.objects.all()
    l1=[]
    for i in obj1:
        l1.append((i.title,i.val))
    l1.sort(key = lambda x: x[1])
    obj2=models.rating.objects.all()
    l2=[]
    for i in obj2:
        if i.email==email:
            l2.append(i.title)
    # print(l2,email)
    l3=[]
    for i in l1:
        if i[0] not in l2:
            # print(i.title)
            l3.append(i[0])
    s=[]
    for i in l3[::-1]:
        s.append(models.movies.objects.get(title=i))
    # print(s)
    return render(request,"signup/movies.html",{"m1":s})

# def games(request):
#     email=request.session['email']
#     return render(request,"signup/games.html")        