from enum import unique
from django.db import models

class student(models.Model):
    fullname=models.CharField(max_length=50)
    passwd=models.CharField(max_length=20)
    cpasswd=models.CharField(max_length=20)
    email=models.CharField(max_length=50,unique=True)
    branch=models.TextField(max_length=50)
    interest=models.TextField(max_length=100)
    
class professor(models.Model):
    fullname=models.CharField(max_length=50)
    passwd=models.CharField(max_length=20)
    cpasswd=models.CharField(max_length=20)
    email=models.CharField(max_length=50,unique=True)

class project(models.Model):
    modalfind=models.TextField(default="")
    email=models.CharField(max_length=50)
    projecttitle=models.TextField(default="")
    description=models.TextField(default="")
    department=models.TextField(default="")
    startdate=models.TextField(default="")
    duration=models.TextField(default="")
    applyby=models.TextField(default="")
    requiredskills=models.TextField(default="")
    perks=models.TextField(default="")
    numberofstudents=models.TextField(default="")
    fullname=models.CharField(max_length=50,default="")

class society(models.Model):
    fullname=models.CharField(max_length=50)
    passwd=models.CharField(max_length=20)
    cpasswd=models.CharField(max_length=20)
    email=models.CharField(max_length=50,unique=True)

class event(models.Model):
    email=models.CharField(max_length=50)
    eventtitle=models.TextField(default="")
    description=models.TextField(default="")
    startdate=models.TextField(default="")
    enddate=models.TextField(default="")
    venue=models.TextField(default="")
    instagramlink=models.TextField(default="")
    registrationlinks=models.TextField(default="")
    imageurl=models.URLField(default="")
    fullname=models.CharField(max_length=50,default="")
    modalfind=models.TextField(default="")

class trips(models.Model):
    startdate=models.TextField(default="")
    enddate=models.TextField(default="")
    destination=models.TextField(default="")
    perheadbudget=models.TextField(default="")
    departure=models.TextField(default="")
    fullname=models.CharField(max_length=50,default="")
    email=models.CharField(max_length=50,default="")
    cnt=models.IntegerField(default=0)
    modalfind=models.TextField(default="")
    link=models.TextField(default="")

class tripimg(models.Model):
    id = models.IntegerField(primary_key=True)
    name=models.TextField(default="")
    link=models.TextField(default="")

class courses(models.Model):
    id = models.IntegerField(primary_key=True)
    coursename=models.CharField(max_length=100)
    links=models.TextField()
    books=models.TextField()

class discussion(models.Model):
    email=models.CharField(max_length=50)
    fullname=models.CharField(max_length=50,default="")
    comment=models.TextField(default="")
    ids = models.IntegerField()

class movies(models.Model):
    title = models.CharField(max_length=200)
    genre = models.CharField(max_length=100)
    movie_logo = models.URLField()

class rating(models.Model):
    email=models.CharField(max_length=50)
    title = models.CharField(max_length=200)
class count(models.Model):
    title = models.CharField(max_length=200)
    val = models.IntegerField(default=0)
